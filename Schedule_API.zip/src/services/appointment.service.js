// appointment.service.js
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

class AppointmentService {
  static async create(data) {
    try {
      return await prisma.appointment.create({ data });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao criar o agendamento');
    }
  }

  static async findMany() {
    try {
      return await prisma.appointment.findMany();
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao buscar os agendamentos');
    }
  }

  static async findUnique(id) {
    try {
      return await prisma.appointment.findUnique({ where: { id } });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao buscar o agendamento');
    }
  }

  static async update(id, data) {
    try {
      return await prisma.appointment.update({ where: { id }, data });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao atualizar o agendamento');
    }
  }

  static async delete(id) {
    try {
      return await prisma.appointment.delete({ where: { id } });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao excluir o agendamento');
    }
  }
}

export default AppointmentService;
