import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

class DoctorConfigService {
  static async create(data) {
    try {
      data.doctorId = data.doctor_id;
      delete data.doctor_id;

      if (!data.doctorId) {
        throw new Error('O ID do médico é obrigatório.');
      }

      const newData = {
        ...data,
        doctor: {
          connect: { id: data.doctorId }
        }
      };
      return await prisma.doctorConfig.create({ data: newData });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao criar a configuração do médico');
    }
  }

  static async findMany() {
    try {
      return await prisma.doctorConfig.findMany();
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao buscar as configurações dos médicos');
    }
  }

  static async findUnique(id) {
    try {
      return await prisma.doctorConfig.findUnique({ where: { id } });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao buscar a configuração do médico');
    }
  }

  static async update(id, data) {
    try {
      return await prisma.doctorConfig.update({ where: { id }, data });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao atualizar a configuração do médico');
    }
  }

  static async delete(id) {
    try {
      return await prisma.doctorConfig.delete({ where: { id } });
    } catch (error) {
      console.error(error);
      throw new Error('Erro ao excluir a configuração do médico');
    }
  }
}

export default DoctorConfigService;
